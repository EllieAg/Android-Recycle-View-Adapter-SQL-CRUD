package com.example.miamidadeanimalshelter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PetAdapterClass extends RecyclerView.Adapter<PetAdapterClass.ViewHolder> {

    List<PetModelClass> pet;
    Context context;
    DatabaseHelperClass databaseHelperClass;

    public PetAdapterClass(List<PetModelClass> pet, Context context) {
        this.pet = pet;
        this.context = context;
        databaseHelperClass = new DatabaseHelperClass(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.pet_item_list,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        final PetModelClass petModelClass = pet.get(position);

        holder.pet_id.setText(Integer.toString(petModelClass.getId()));
        holder.pet_name.setText(petModelClass.getName());
        holder.pet_description.setText(petModelClass.getDescription());

        holder.button_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stringName = holder.pet_name.getText().toString();
                String stringDescription = holder.pet_description.getText().toString();

                databaseHelperClass.updatePet(new PetModelClass(petModelClass.getId(),stringName,stringDescription));
                notifyDataSetChanged();
                ((Activity) context).finish();
                context.startActivity(((Activity) context).getIntent());
            }
        });

        holder.button_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelperClass.deletePet(petModelClass.getId());
                pet.remove(position);
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return pet.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView pet_id;
        EditText pet_name;
        EditText pet_description;
        Button button_edit;
        Button button_delete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            pet_id = itemView.findViewById(R.id.pet_id);
            pet_name = itemView.findViewById(R.id.pet_name);
            pet_description = itemView.findViewById(R.id.pet_description);
            button_delete = itemView.findViewById(R.id.button_delete);
            button_edit = itemView.findViewById(R.id.button_edit);

        }
    }
}
